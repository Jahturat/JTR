"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import LoadingAnimation from "@/components/loading-animation"

export default function Home() {
  const router = useRouter()

  useEffect(() => {
    // Redirect after 3 seconds
    const timer = setTimeout(() => {
      window.location.href = "https://golden-skull-shop.vercel.app"
    }, 3000)

    return () => clearTimeout(timer)
  }, [router])

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-gray-900 text-white">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-6">กำลังเคลื่อนย้ายไปยัง ✨ Golden Skull Shop</h1>
        <LoadingAnimation />
        <p className="mt-4 text-gray-400">กรุณารอสักครู่...</p>
      </div>
    </main>
  )
}
