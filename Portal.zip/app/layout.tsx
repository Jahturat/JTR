import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "✨ Golden Skull Shop",
  description: "พอทัลไปยังร้านค้า",
  icons: {
    icon: [
      {
        url: "https://ib9atljnugyqkwms.public.blob.vercel-storage.com/Pics/logo/raw%20%289%29-Xssamh5gPBkmJC7mZVZkE9Gp5Ovds7.png",
        href: "https://ib9atljnugyqkwms.public.blob.vercel-storage.com/Pics/logo/raw%20%289%29-Xssamh5gPBkmJC7mZVZkE9Gp5Ovds7.png",
      },
    ],
    apple:
      "https://ib9atljnugyqkwms.public.blob.vercel-storage.com/Pics/logo/raw%20%289%29-Xssamh5gPBkmJC7mZVZkE9Gp5Ovds7.png",
  },
  openGraph: {
    title: "✨ Golden Skull Shop",
    description: "พอทัลไปยังร้านค้า",
    images: [
      {
        url: "https://ib9atljnugyqkwms.public.blob.vercel-storage.com/Pics/logo/raw%20%289%29-Xssamh5gPBkmJC7mZVZkE9Gp5Ovds7.png",
        width: 1200,
        height: 1200,
        alt: "Golden Skull Shop Logo",
      },
    ],
    locale: "th_TH",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Golden Skull Shop",
    description: "พอทัลไปยังร้านค้า",
    images: [
      "https://ib9atljnugyqkwms.public.blob.vercel-storage.com/Pics/logo/raw%20%289%29-Xssamh5gPBkmJC7mZVZkE9Gp5Ovds7.png",
    ],
  },
  manifest: "/manifest.json",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="th">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700;900&display=swap"
          rel="stylesheet"
        />
        <link
          rel="icon"
          href="https://ib9atljnugyqkwms.public.blob.vercel-storage.com/Pics/logo/raw%20%289%29-Xssamh5gPBkmJC7mZVZkE9Gp5Ovds7.png"
        />
      </head>
      <body className={inter.className}>{children}</body>
    </html>
  )
}
